# docdoc_app

 onBoarding Screen 
![Screenshot 2025-03-27 185834](https://github.com/user-attachments/assets/5c15289a-3944-4737-8bca-9b93d8882123)
