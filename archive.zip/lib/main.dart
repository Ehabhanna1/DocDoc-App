import 'package:docdoc_app/core/routing/app_router.dart';
import 'package:docdoc_app/docdoc_app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp( DocdocApp(
    appRouter: AppRouter(),
  ));
}



