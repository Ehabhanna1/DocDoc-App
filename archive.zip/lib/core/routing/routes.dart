class Routes {



  static const String onBoardingScreen = '/onboarding';

  static const String loginScreen = '/login';

  
}