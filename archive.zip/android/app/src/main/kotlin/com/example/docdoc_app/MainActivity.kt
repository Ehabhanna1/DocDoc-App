package com.example.docdoc_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
